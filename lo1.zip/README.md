# Discord Multi-Guild Bot

บอทจัดการหลายเซิร์ฟเวอร์ พร้อม Web Dashboard และซิงก์ config ผ่าน GitHub

## ฟีเจอร์หลัก

- **Temp voice channels** — เข้า lobby แล้วสร้างห้อง voice ชั่วคราวอัตโนมัติ ลบเมื่อว่าง
- **Voice notifications** — แจ้งเตือนเมื่อสมาชิกเข้า/ออก/ย้าย voice channel
- **Link filter** — ลบข้อความที่มีลิงก์ (ยกเว้น channel/guild ได้)
- **Invite Hub** — สร้าง invite ทุกเซิร์ฟเวอร์อัตโนมัติในช่องที่กำหนด
- **Emoji uploader** — อัปโหลดอีโมจิจากโฟลเดอร์ `Emoji/`
- **Web Dashboard** — ตั้งค่า Voice, Temp Voice, Link Filter ต่อ guild ผ่านเบราว์เซอร์ (`/dashboard`)

## รันโปรเจกต์

**Windows**
```bat
Run.bat
```

**Linux/macOS**
```bash
./run.sh
```

## ตัวแปรสภาพแวดล้อม (.env)

| ตัวแปร | จำเป็น | คำอธิบาย |
|--------|--------|----------|
| `DISCORD_TOKEN` | ใช่ | Token ของ Discord bot |
| `DASHBOARD_PASSWORD` | แนะนำ | รหัสผ่านเข้า Dashboard |
| `GITHUB_TOKEN` | ไม่ | Token สำหรับ sync config ไป GitHub (ไม่มี = โหมด local) |
| `GITHUB_REPO` | ไม่ | Repo เก็บ config (ค่าเริ่มต้น `fomm1802/Bot`) |
| `GITHUB_BRANCH` | ไม่ | Branch (ค่าเริ่มต้น `main`) |
| `GITHUB_WEBHOOK_SECRET` | ไม่ | Secret สำหรับ `/github-sync` webhook |
| `WEBHOOK_PORT` | ไม่ | พอร์ต web server (ค่าเริ่มต้น `12214`) |
| `INVITE_HUB_CHANNEL_ID` | ไม่ | Channel ID สำหรับ Invite Hub |
| `INVITE_SYNC_INTERVAL_MINUTES` | ไม่ | ช่วงซิงก์ invite (ค่าเริ่มต้น 30 นาที) |
| `BOT_PREFIX` | ไม่ | Prefix คำสั่ง (ค่าเริ่มต้น `!`) |

## Endpoints

| Path | คำอธิบาย |
|------|----------|
| `/` | สถานะ bot (JSON) |
| `/healthz` | Health check |
| `/dashboard` | หน้าตั้งค่า |
| `/github-sync` | Webhook จาก GitHub |

## Dashboard

เข้า `http://<host>:<WEBHOOK_PORT>/dashboard` แล้วล็อกอินด้วย `DASHBOARD_PASSWORD`

ตั้งค่าได้ครบต่อเซิร์ฟเวอร์:

| หมวด | รายการ |
|------|--------|
| **Voice** | ช่องแจ้งเตือน, Join Here |
| **Temp Voice** | เปิด/ปิด, Lobby, Category, รูปแบบชื่อ (`{user}`), จำกัดคน |
| **Link Filter** | ยกเว้นทั้งเซิร์ฟ, ช่องยกเว้น, โดเมนที่อนุญาต |

## คำสั่ง Slash

> การตั้งค่า Voice, Temp Voice และ Link Filter แนะนำผ่าน **Dashboard**

- `/help` — แสดงเมนูคำสั่งทั้งหมด
- `/view_config` — ดูการตั้งค่าของเซิร์ฟเวอร์ (รวม Temp Voice)
- `/link_filter_status` — ดูสถานะตัวกรองลิงก์
- `/bot_status` — ดูสถานะ uptime และทรัพยากรบอท
- `/server_info` — ดูข้อมูลเซิร์ฟเวอร์
- `/invite_sync_now` / `/invite_set_interval` — จัดการ Invite Hub
- `/upload_emojis_gawrgura` — อัปโหลดอีโมจิ

## ทดสอบ / Benchmark

```bash
python -m py_compile bot.py utils.py web/__init__.py
python benchmarks/benchmark_concurrency.py
```
