from pathlib import Path
from typing import Optional

from utils import get_server_config_local, normalize_domain_list, save_server_config

DEFAULT_TEMP_NAME_FORMAT = "🔊 {user}"


def _parse_optional_int(raw: str) -> int | None:
    raw = (raw or "").strip()
    return int(raw) if raw.isdigit() else None


def _parse_user_limit(raw: str) -> int:
    if not (raw or "").strip().isdigit():
        return 0
    value = int(raw.strip())
    return max(0, min(value, 99))


def load_dashboard_rows(active_bot: Optional[object]) -> list[dict]:
    rows: list[dict] = []
    config_dir = Path("configs")
    guilds = {}
    guild_ids: set[str] = set()

    if active_bot and getattr(active_bot, "guilds", None):
        guilds = {str(g.id): g for g in active_bot.guilds}
        guild_ids.update(guilds.keys())

    if config_dir.exists():
        for config_file in sorted(config_dir.glob("*.json")):
            guild_ids.add(config_file.stem)

    for gid in sorted(guild_ids, key=int):
        cfg = get_server_config_local(gid)
        guild = guilds.get(gid)
        channels = sorted((guild.text_channels if guild else []), key=lambda c: c.position)
        voice_channels = sorted(
            (guild.voice_channels if guild else []),
            key=lambda c: c.position,
        )
        categories = sorted((guild.categories if guild else []), key=lambda c: c.position)

        channel_options = [{"id": str(ch.id), "name": ch.name} for ch in channels]
        voice_channel_options = [{"id": str(ch.id), "name": ch.name} for ch in voice_channels]
        category_options = [{"id": str(cat.id), "name": cat.name} for cat in categories]

        join_here_id = str(cfg.get("join_here_channel_id") or "")
        if not join_here_id and cfg.get("join_here_channel_name"):
            for ch in voice_channels:
                if ch.name == cfg["join_here_channel_name"]:
                    join_here_id = str(ch.id)
                    break

        rows.append(
            {
                "guild_id": gid,
                "guild_name": guild.name if guild else f"Guild {gid}",
                "notify_channel_id": str(cfg.get("notify_channel_id") or ""),
                "join_here_channel_id": join_here_id,
                "join_here_channel_name": cfg.get("join_here_channel_name") or "",
                "channel_options": channel_options,
                "voice_channel_options": voice_channel_options,
                "category_options": category_options,
                "selected_exempt_channels": {
                    str(ch_id) for ch_id in cfg.get("exempt_channels", [])
                },
                "exempt_guild": bool(cfg.get("exempt_guild", False)),
                "allowed_link_domains_text": "\n".join(
                    normalize_domain_list(cfg.get("allowed_link_domains", []))
                ),
                "temp_voice_enabled": bool(cfg.get("temp_voice_enabled", False)),
                "temp_voice_lobby_id": str(cfg.get("temp_voice_lobby_id") or ""),
                "temp_voice_category_id": str(cfg.get("temp_voice_category_id") or ""),
                "temp_voice_name_format": cfg.get("temp_voice_name_format")
                or DEFAULT_TEMP_NAME_FORMAT,
                "temp_voice_user_limit": str(cfg.get("temp_voice_user_limit") or 0),
            }
        )
    return rows


def save_dashboard_config(
    guild_id: str,
    notify_raw: str,
    join_here_raw: str,
    exempt_channel_ids: list[str],
    exempt_guild_enabled: bool,
    allowed_domains_raw: str = "",
    temp_voice_enabled: bool = False,
    temp_voice_lobby_raw: str = "",
    temp_voice_category_raw: str = "",
    temp_voice_name_format: str = "",
    temp_voice_user_limit_raw: str = "0",
    active_bot: Optional[object] = None,
) -> None:
    cfg = get_server_config_local(guild_id)
    cfg["notify_channel_id"] = _parse_optional_int(notify_raw)
    cfg["join_here_channel_id"] = _parse_optional_int(join_here_raw)
    cfg["join_here_channel_name"] = None
    if cfg["join_here_channel_id"] and active_bot:
        guild = active_bot.get_guild(int(guild_id)) if guild_id.isdigit() else None
        channel = guild.get_channel(cfg["join_here_channel_id"]) if guild else None
        cfg["join_here_channel_name"] = getattr(channel, "name", None)

    cfg["exempt_channels"] = [
        int(ch_id) for ch_id in exempt_channel_ids if ch_id.isdigit()
    ]
    cfg["exempt_guild"] = exempt_guild_enabled
    cfg["allowed_link_domains"] = normalize_domain_list(allowed_domains_raw)

    cfg["temp_voice_enabled"] = temp_voice_enabled
    cfg["temp_voice_lobby_id"] = _parse_optional_int(temp_voice_lobby_raw)
    cfg["temp_voice_category_id"] = _parse_optional_int(temp_voice_category_raw)

    name_fmt = (temp_voice_name_format or "").strip() or DEFAULT_TEMP_NAME_FORMAT
    cfg["temp_voice_name_format"] = name_fmt[:100]
    cfg["temp_voice_user_limit"] = _parse_user_limit(temp_voice_user_limit_raw)

    if temp_voice_enabled and not cfg["temp_voice_lobby_id"]:
        cfg["temp_voice_enabled"] = False

    save_server_config(guild_id, cfg)
