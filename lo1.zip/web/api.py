﻿import time
from typing import Callable, Optional

from flask import Blueprint, jsonify


def create_api_blueprint(get_bot: Callable[[], Optional[object]]) -> Blueprint:
    bp = Blueprint("api", __name__)

    @bp.get("/healthz")
    def healthz():
        return jsonify({"ok": True}), 200

    from flask import redirect, url_for

    @bp.get("/")
    def index():
        return redirect(url_for("dashboard.home"))

    @bp.get("/status")
    def status():
        bot = get_bot()
        if not bot or not bot.is_ready():
            return jsonify({"online": False})
        uptime = int(time.time() - bot.start_time)
        return jsonify({
            "online": True,
            "user": str(bot.user),
            "guilds": len(bot.guilds),
            "latency_ms": round(bot.latency * 1000),
            "uptime_sec": uptime,
        })

    return bp

