﻿import asyncio
from unittest.mock import AsyncMock, MagicMock
import sys
import os

sys.path.append(os.path.abspath('.'))

import discord
from discord.ext import commands
from cogs.events.voice_events import VoiceEvents
import utils

class MockBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix='!')
        self.temp_voice_channel_ids = {123456789}

async def main():
    bot = MockBot()
    cog = VoiceEvents(bot)

    guild = MagicMock(spec=discord.Guild)
    guild.id = 111111111
    
    member = MagicMock(spec=discord.Member)
    member.guild = guild
    member.bot = False
    member.display_name = 'Rei_Sood_Zeed'
    member.display_avatar.url = 'https://example.com/avatar.png'

    mock_config = {
        'notify_channel_id': 999999999,
        'join_here_channel_id': 888888888,
        'temp_voice_enabled': True,
        'temp_voice_lobby_id': 777777777,
    }
    
    utils.async_get_server_config = AsyncMock(return_value=mock_config)

    notify_channel = MagicMock(spec=discord.TextChannel)
    notify_channel.permissions_for = MagicMock(return_value=MagicMock(send_messages=True))
    notify_channel.send = AsyncMock()
    guild.get_channel = MagicMock(return_value=notify_channel)

    before_state = MagicMock(spec=discord.VoiceState)
    before_state.channel = None

    temp_channel = MagicMock(spec=discord.VoiceChannel)
    temp_channel.id = 123456789
    temp_channel.name = '🎙️ Room 1'
    
    after_state = MagicMock(spec=discord.VoiceState)
    after_state.channel = temp_channel

    print('📢 [จําลอง] กำลังจำลองผู้ใช้เข้าห้อง Temp Voice...')
    await cog.on_voice_state_update(member, before_state, after_state)

    if notify_channel.send.called:
        called_args, called_kwargs = notify_channel.send.call_args
        embed = called_kwargs.get('embed')
        print('✅ [ผลลัพธ์] บอททำการส่งข้อความแจ้งเตือนเรียบร้อย!')
        print(f'   📝 หัวข้อ Embed: {embed.title}')
        print(f'   📝 คำอธิบาย Embed: {embed.description}')
    else:
        print('❌ [ผลลัพธ์] บอทไม่ได้ส่งข้อความแจ้งเตือน (เงื่อนไขถูกข้าม)')

if __name__ == '__main__':
    asyncio.run(main())
