﻿import os
import time
import logging
import traceback
import asyncio
import signal
from threading import Thread
from typing import Optional

import psutil
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
import coloredlogs

from utils import (
    async_get_server_config,
    async_full_sync,
    async_save_server_config,
    check_github_token,
    default_config,
)
from web import create_web_app


# ---------- Load .env ----------
load_dotenv()

# ---------- Logging ----------
coloredlogs.install(
    level=logging.INFO,
    fmt="%(asctime)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger("discord_bot")


# ---------- Flask Server ----------
WEBHOOK_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "")
DASHBOARD_PASSWORD = os.getenv("DASHBOARD_PASSWORD", "").strip()

bot: Optional["MyBot"] = None
app = create_web_app(
    get_bot=lambda: bot,
    dashboard_password=DASHBOARD_PASSWORD,
    webhook_secret=WEBHOOK_SECRET,
    logger=logger,
)


def run_flask():
    port = int(os.getenv("WEBHOOK_PORT") or os.getenv("SERVER_PORT") or 12214)

    try:
        from waitress import serve

        logger.info(f"🌐 Starting dashboard/webhook server with Waitress on :{port}")
        serve(app, host="0.0.0.0", port=port, threads=8)
        return
    except Exception:
        logger.warning("⚠️ Waitress unavailable, fallback to Flask built-in server")

    logging.getLogger("werkzeug").setLevel(logging.ERROR)
    app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)


# ---------- Bot Presence Status ----------
async def update_bot_status(bot_instance: "MyBot"):
    await bot_instance.wait_until_ready()

    process = psutil.Process()
    member_count_cache = 0
    member_count_refreshed_at = 0.0

    while not bot_instance.is_closed():
        uptime = int(time.time() - bot_instance.start_time)

        hours = uptime // 3600
        minutes = (uptime % 3600) // 60
        seconds = uptime % 60

        guild_count = len(bot_instance.guilds)

        now = time.time()
        if (now - member_count_refreshed_at) >= 60:
            member_count_cache = sum((g.member_count or 0) for g in bot_instance.guilds)
            member_count_refreshed_at = now

        total_members = member_count_cache
        cpu_usage = psutil.cpu_percent(interval=None)
        mem_mb = int(process.memory_info().rss / 1024 / 1024)

        status_text = (
            f"🟢 Online | {guild_count} Servers — "
            f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        )
        sys_info = (
            f"👥 {total_members} Members | "
            f"💻 CPU {cpu_usage:.0f}% | "
            f"🧠 {mem_mb}MB"
        )

        try:
            await bot_instance.change_presence(
                activity=discord.CustomActivity(name=f"{status_text} | {sys_info}"),
                status=discord.Status.online,
            )
        except Exception:
            pass

        await asyncio.sleep(30)


# ---------- Discord Bot ----------
PREFIX = os.getenv("BOT_PREFIX", "!")

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True
intents.voice_states = True

COGS = [
    "cogs.commands.help_menu",
    "cogs.commands.guild_config",
    "cogs.commands.bot_status",
    "cogs.commands.emoji_uploader",
    "cogs.commands.set_notify_channel",
    "cogs.commands.invite_all",
    "cogs.events.link_detection",
    "cogs.events.temp_voice",
    "cogs.events.voice_events",
]


class MyBot(commands.AutoShardedBot):
    def __init__(self):
        super().__init__(command_prefix=PREFIX, intents=intents)
        self.start_time = time.time()
        self.status_task: Optional[asyncio.Task] = None

    async def setup_hook(self):
        for cog in COGS:
            try:
                await self.load_extension(cog)
                logger.info(f"✅ โหลด {cog} สำเร็จ")
            except Exception:
                logger.error(traceback.format_exc())

        self.tree.on_error = self._on_app_command_error

        try:
            await self.tree.sync()
            logger.info("✅ ซิงค์ Slash Commands สำเร็จ")
        except Exception:
            logger.error("❌ Sync คำสั่งล้มเหลว")

    async def _on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ):
        if isinstance(error, app_commands.CommandOnCooldown):
            msg = f"⏳ รอ {error.retry_after:.1f} วินาทีก่อนใช้คำสั่งอีกครั้ง"
        elif isinstance(error, app_commands.MissingPermissions):
            msg = "❌ คุณไม่มีสิทธิ์ใช้คำสั่งนี้"
        elif isinstance(error, app_commands.BotMissingPermissions):
            perms = ", ".join(error.missing_permissions)
            msg = f"❌ บอทขาดสิทธิ์: {perms}"
        else:
            logger.error("Slash command error: %s", error, exc_info=error)
            msg = "❌ เกิดข้อผิดพลาด ลองใหม่อีกครั้ง"

        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except discord.HTTPException:
            pass

    async def close(self):
        if self.status_task and not self.status_task.done():
            self.status_task.cancel()
            try:
                await self.status_task
            except asyncio.CancelledError:
                pass
        await super().close()

    async def on_ready(self):
        logger.info(f"👋 Logged in as {self.user} ({self.user.id})")

        await async_full_sync()

        semaphore = asyncio.Semaphore(20)

        async def warmup_config(gid: int):
            async with semaphore:
                await async_get_server_config(gid)

        await asyncio.gather(*(warmup_config(g.id) for g in self.guilds))

        logger.info("✅ Config sync เรียบร้อย")

        if not self.status_task or self.status_task.done():
            self.status_task = self.loop.create_task(update_bot_status(self))

    async def on_guild_join(self, guild: discord.Guild):
        logger.info("➕ เข้าเซิร์ฟเวอร์ใหม่: %s (%s)", guild.name, guild.id)
        await async_save_server_config(guild.id, default_config())

    async def on_guild_remove(self, guild: discord.Guild):
        logger.info("➖ ออกจากเซิร์ฟเวอร์: %s (%s)", guild.name, guild.id)

    async def on_disconnect(self):
        logger.warning("⚠️ ตัดการเชื่อมต่อ Discord — กำลัง reconnect...")


# ---------- Entrypoint ----------
async def main():
    global bot

    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.error("❌ ไม่มี DISCORD_TOKEN ใน .env")
        return

    if not check_github_token():
        logger.warning("⚠️ ไม่มี GITHUB_TOKEN: โหมด Local-Only")

    t = Thread(target=run_flask, daemon=True)
    t.start()

    bot = MyBot()
    loop = asyncio.get_running_loop()

    def _request_shutdown():
        logger.info("🛑 รับสัญญาณปิด — กำลัง disconnect...")
        loop.create_task(bot.close())

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_shutdown)
        except NotImplementedError:
            pass

    try:
        await bot.start(token)
    except KeyboardInterrupt:
        await bot.close()
    finally:
        logger.info("👋 บอทปิดเรียบร้อย")


if __name__ == "__main__":
    asyncio.run(main())

