﻿import logging
from datetime import datetime

import discord
from discord.ext import commands
import pytz

from utils import async_get_server_config

logger = logging.getLogger("discord_bot")
BANGKOK = pytz.timezone("Asia/Bangkok")

class VoiceEvents(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @staticmethod
    def _is_skip_channel(
        channel: discord.VoiceChannel | discord.StageChannel | None,
        join_here_id: int | None,
        join_here_name: str | None,
        temp_lobby_id: int | None,
        temp_channel_ids: set[int],
    ) -> bool:
        if channel is None:
            return False
        if join_here_id and channel.id == join_here_id:
            return True
        if join_here_name and channel.name == join_here_name:
            return True
        if temp_lobby_id and channel.id == temp_lobby_id:
            return True
        return False

    @staticmethod
    def _embed_for(
        member: discord.Member,
        event: str,
        *,
        before_ch: str | None = None,
        after_ch: str | None = None,
    ) -> discord.Embed:
        thai_time = datetime.now(BANGKOK)
        styles = {
            "join": (
                "🔊 สมาชิกเข้าช่องเสียง",
                discord.Color.green(),
            ),
            "leave": (
                "🔉 สมาชิกออกจากช่องเสียง",
                discord.Color.red(),
            ),
            "move": (
                "🔄 สมาชิกย้ายช่องเสียง",
                discord.Color.orange(),
            ),
        }
        title, color = styles[event]
        embed = discord.Embed(title=title, timestamp=thai_time, color=color)
        embed.set_author(name=member.display_name, icon_url=member.display_avatar.url)
        
        embed.add_field(name="👤 สมาชิก", value=member.mention, inline=True)
        if event == "join":
            embed.add_field(name="📥 ช่อง", value=f"{after_ch}", inline=True)
        elif event == "leave":
            embed.add_field(name="📤 ช่อง", value=f"{before_ch}", inline=True)
        elif event == "move":
            embed.add_field(name="🔙 จากห้อง", value=f"{before_ch}", inline=True)
            embed.add_field(name="🔜 ไปยังห้อง", value=f"{after_ch}", inline=True)
            
        embed.set_footer(text="🕒 เวลาที่เกิดเหตุการณ์")
        return embed

    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ):
        if member.bot or before.channel == after.channel:
            return

        cfg = await async_get_server_config(member.guild.id)
        notify_channel_id = cfg.get("notify_channel_id")
        if not notify_channel_id:
            return

        channel = member.guild.get_channel(notify_channel_id)
        if not channel or not channel.permissions_for(member.guild.me).send_messages:
            return

        join_here_id = cfg.get("join_here_channel_id")
        join_here_name = (cfg.get("join_here_channel_name") or "").strip() or None
        temp_lobby_id = cfg.get("temp_voice_lobby_id") if cfg.get("temp_voice_enabled") else None
        temp_channel_ids = getattr(self.bot, "temp_voice_channel_ids", set())

        def should_skip(ch):
            return self._is_skip_channel(
                ch, join_here_id, join_here_name, temp_lobby_id, temp_channel_ids
            )

        try:
            if before.channel is None and after.channel is not None:
                if should_skip(after.channel):
                    return
                await channel.send(embed=self._embed_for(member, "join", after_ch=after.channel.name))

            elif before.channel is not None and after.channel is None:
                if should_skip(before.channel):
                    return
                await channel.send(embed=self._embed_for(member, "leave", before_ch=before.channel.name))

            elif before.channel != after.channel:
                skip_before = should_skip(before.channel)
                skip_after = should_skip(after.channel)

                if skip_before and skip_after:
                    return

                if skip_before and not skip_after:
                    await channel.send(embed=self._embed_for(member, "join", after_ch=after.channel.name))
                elif not skip_before and skip_after:
                    await channel.send(embed=self._embed_for(member, "leave", before_ch=before.channel.name))
                else:
                    await channel.send(
                        embed=self._embed_for(
                            member,
                            "move",
                            before_ch=before.channel.name if before.channel else "N/A",
                            after_ch=after.channel.name if after.channel else "N/A",
                        )
                    )
        except discord.HTTPException as exc:
            logger.error("❌ เกิดข้อผิดพลาดขณะส่งข้อความ voice: %s", exc)

async def setup(bot: commands.Bot):
    await bot.add_cog(VoiceEvents(bot))
