import re
import time
import discord
from discord.ext import commands
from discord import app_commands

from utils import (
    async_get_server_config,
    async_save_server_config,
    normalize_domain,
    normalize_domain_list,
)


LINK_PATTERN = re.compile(
    r"(?i)\b(?:https?://|www\.)?"
    r"(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"[a-z]{2,63}"
    r"(?:/[^\s<>)\"]*)?"
)


class LinkFilter(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._processing: dict[int, float] = {}

    async def load_config(self, guild_id: str) -> dict:
        cfg = dict(await async_get_server_config(guild_id) or {})
        cfg.setdefault("notify_channel_id", None)
        cfg["exempt_channels"] = set(cfg.get("exempt_channels", []))
        cfg["exempt_guild"] = bool(cfg.get("exempt_guild", False))
        cfg["allowed_link_domains"] = normalize_domain_list(
            cfg.get("allowed_link_domains", [])
        )
        return cfg

    async def save_config(self, guild_id: str, cfg: dict, **updates):
        cfg.update(updates)
        if isinstance(cfg.get("exempt_channels"), set):
            cfg["exempt_channels"] = list(cfg["exempt_channels"])
        cfg["allowed_link_domains"] = normalize_domain_list(
            cfg.get("allowed_link_domains", [])
        )
        await async_save_server_config(guild_id, cfg)

    def _mark_processing(self, message_id: int) -> bool:
        now = time.time()
        if message_id in self._processing:
            return False
        self._processing[message_id] = now
        if len(self._processing) > 500:
            cutoff = now - 60
            self._processing = {
                mid: ts for mid, ts in self._processing.items() if ts > cutoff
            }
        return True

    def _contains_link(self, text: str) -> bool:
        return bool(LINK_PATTERN.search(text))

    def _extract_link_domains(self, text: str) -> list[str]:
        domains = []
        seen = set()
        for match in LINK_PATTERN.finditer(text):
            domain = normalize_domain(match.group(0))
            if domain and domain not in seen:
                domains.append(domain)
                seen.add(domain)
        return domains

    def _is_domain_allowed(self, domain: str, allowed_domains: list[str]) -> bool:
        return any(
            domain == allowed or domain.endswith(f".{allowed}")
            for allowed in allowed_domains
        )

    @app_commands.command(
        name="allow_link_domain",
        description="อนุญาตโดเมนลิงก์ผ่านตัวกรอง",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def allow_link_domain(self, interaction: discord.Interaction, domain: str):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)
        cleaned = normalize_domain(domain)

        if not cleaned:
            await interaction.response.send_message(
                "❌ โดเมนไม่ถูกต้อง ตัวอย่าง: youtube.com", ephemeral=True
            )
            return

        allowed = cfg["allowed_link_domains"]
        if cleaned in allowed:
            await interaction.response.send_message(
                f"⚠️ `{cleaned}` อยู่ในรายการอนุญาตแล้ว", ephemeral=True
            )
            return

        allowed.append(cleaned)
        await self.save_config(gid, cfg, allowed_link_domains=allowed)
        await interaction.response.send_message(
            f"✅ อนุญาตโดเมน: `{cleaned}`", ephemeral=True
        )

    @app_commands.command(
        name="remove_allowed_link_domain",
        description="ลบโดเมนออกจากรายการอนุญาต",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_allowed_link_domain(
        self,
        interaction: discord.Interaction,
        domain: str,
    ):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)
        cleaned = normalize_domain(domain)

        if not cleaned or cleaned not in cfg["allowed_link_domains"]:
            await interaction.response.send_message(
                "⚠️ โดเมนนี้ไม่อยู่ในรายการอนุญาต", ephemeral=True
            )
            return

        allowed = [item for item in cfg["allowed_link_domains"] if item != cleaned]
        await self.save_config(gid, cfg, allowed_link_domains=allowed)
        await interaction.response.send_message(
            f"✅ ลบโดเมน `{cleaned}` แล้ว", ephemeral=True
        )

    @app_commands.command(
        name="list_allowed_link_domains",
        description="ดูรายการโดเมนที่อนุญาตผ่านตัวกรอง",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def list_allowed_link_domains(self, interaction: discord.Interaction):
        cfg = await self.load_config(str(interaction.guild.id))
        allowed = cfg["allowed_link_domains"]
        if not allowed:
            await interaction.response.send_message(
                "ℹ️ ยังไม่มีโดเมนที่อนุญาต", ephemeral=True
            )
            return

        body = "\n".join(f"- `{domain}`" for domain in allowed)
        await interaction.response.send_message(
            f"✅ โดเมนที่อนุญาต:\n{body}", ephemeral=True
        )

    @app_commands.command(
        name="link_filter_status",
        description="ดูสถานะระบบกรองลิงก์ของเซิร์ฟเวอร์",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def link_filter_status(self, interaction: discord.Interaction):
        cfg = await self.load_config(str(interaction.guild.id))
        exempt = cfg["exempt_channels"]
        allowed = cfg["allowed_link_domains"]

        exempt_lines = []
        for cid in list(exempt)[:8]:
            ch = interaction.guild.get_channel(cid)
            exempt_lines.append(ch.mention if ch else f"`{cid}`")
        if len(exempt) > 8:
            exempt_lines.append(f"... และอีก {len(exempt) - 8} ช่อง")

        embed = discord.Embed(
            title="🔗 สถานะตัวกรองลิงก์",
            color=discord.Color.orange(),
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(
            name="ยกเว้นทั้งเซิร์ฟเวอร์",
            value="✅ ใช่" if cfg["exempt_guild"] else "❌ ไม่",
            inline=True,
        )
        embed.add_field(
            name="ช่องยกเว้น",
            value="\n".join(exempt_lines) if exempt_lines else "—",
            inline=False,
        )
        embed.add_field(
            name="โดเมนที่อนุญาต",
            value=", ".join(f"`{d}`" for d in allowed) if allowed else "—",
            inline=False,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(
        name="add_exempt_channel",
        description="เพิ่มห้องที่ไม่ต้องตรวจลิงก์",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def add_exempt_channel(
        self, interaction: discord.Interaction, channel: discord.TextChannel
    ):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)

        if channel.id in cfg["exempt_channels"]:
            await interaction.response.send_message(
                "⚠️ ห้องนี้ถูกยกเว้นอยู่แล้ว", ephemeral=True
            )
            return

        cfg["exempt_channels"].add(channel.id)
        await self.save_config(
            gid, cfg, exempt_channels=list(cfg["exempt_channels"])
        )
        await interaction.response.send_message(
            f"✅ เพิ่ม {channel.mention} เข้ารายการยกเว้น", ephemeral=True
        )

    @app_commands.command(
        name="remove_exempt_channel",
        description="เอาห้องออกจากรายการยกเว้น",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def remove_exempt_channel(
        self, interaction: discord.Interaction, channel: discord.TextChannel
    ):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)

        if channel.id not in cfg["exempt_channels"]:
            await interaction.response.send_message(
                "⚠️ ห้องนี้ไม่ได้อยู่ในรายการ", ephemeral=True
            )
            return

        cfg["exempt_channels"].remove(channel.id)
        await self.save_config(
            gid, cfg, exempt_channels=list(cfg["exempt_channels"])
        )
        await interaction.response.send_message(
            f"❌ เอา {channel.mention} ออกจากรายการแล้ว", ephemeral=True
        )

    @app_commands.command(
        name="exempt_all_channels",
        description="ยกเว้นทั้งเซิร์ฟเวอร์จากระบบกรองลิงก์",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def exempt_all(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)

        if cfg["exempt_guild"]:
            await interaction.response.send_message(
                "⚠️ ทั้งเซิร์ฟเวอร์ถูกยกเว้นอยู่แล้ว", ephemeral=True
            )
            return

        await self.save_config(gid, cfg, exempt_guild=True)
        await interaction.response.send_message(
            "✅ ยกเว้นทั้งเซิร์ฟเวอร์แล้ว", ephemeral=True
        )

    @app_commands.command(
        name="unexempt_all_channels",
        description="ยกเลิกการยกเว้นทั้งเซิร์ฟเวอร์",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def unexempt_all(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        cfg = await self.load_config(gid)

        if not cfg["exempt_guild"]:
            await interaction.response.send_message(
                "⚠️ ยังไม่ได้ถูกยกเว้น", ephemeral=True
            )
            return

        await self.save_config(gid, cfg, exempt_guild=False)
        await interaction.response.send_message(
            "❌ ยกเลิกการยกเว้นแล้ว", ephemeral=True
        )

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        if message.type != discord.MessageType.default:
            return

        text = (message.content or "").strip()
        if not text or not self._contains_link(text):
            return
        domains = self._extract_link_domains(text)
        if not domains:
            return

        gid = str(message.guild.id)
        cfg = await self.load_config(gid)

        if cfg["exempt_guild"]:
            return
        if message.channel.id in cfg["exempt_channels"]:
            return
        blocked_domains = [
            domain
            for domain in domains
            if not self._is_domain_allowed(domain, cfg["allowed_link_domains"])
        ]
        if not blocked_domains:
            return
        if not self._mark_processing(message.id):
            return

        try:
            try:
                await message.delete()
            except discord.Forbidden:
                return
            except discord.NotFound:
                return

            await message.channel.send(
                f"⚠️ {message.author.mention} ข้อความที่มีลิงก์ถูกลบ (กฎเซิร์ฟเวอร์)",
                delete_after=20,
            )

            notify_id = cfg.get("notify_channel_id")
            if notify_id and notify_id != message.channel.id:
                notify_ch = message.guild.get_channel(notify_id)
                if notify_ch and notify_ch.permissions_for(
                    message.guild.me
                ).send_messages:
                    await notify_ch.send(
                        f"🔗 ลบลิงก์ใน {message.channel.mention} โดย {message.author.mention}"
                    )
        finally:
            self._processing.pop(message.id, None)


    async def cog_app_command_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            message = "❌ ต้องมีสิทธิ์ Administrator"
        else:
            message = "❌ คำสั่งล้มเหลว ลองใหม่อีกครั้ง"

        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)


async def setup(bot):
    await bot.add_cog(LinkFilter(bot))
