import asyncio
import logging
import re

import discord
from discord.ext import commands

from utils import async_get_server_config

logger = logging.getLogger("discord_bot")
CHANNEL_NAME_RE = re.compile(r"[^\w\s\-🔊|]", re.UNICODE)


class TempVoice(commands.Cog):
    """สร้างห้อง voice ชั่วคราวเมื่อเข้า lobby channel"""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._temp_channels: dict[int, int] = {}
        self._guild_locks: dict[int, asyncio.Lock] = {}

        if not hasattr(bot, "temp_voice_channel_ids"):
            bot.temp_voice_channel_ids = set()

    def _lock_for(self, guild_id: int) -> asyncio.Lock:
        if guild_id not in self._guild_locks:
            self._guild_locks[guild_id] = asyncio.Lock()
        return self._guild_locks[guild_id]

    @staticmethod
    def _sanitize_channel_name(name: str) -> str:
        cleaned = CHANNEL_NAME_RE.sub("", name.strip())
        return (cleaned[:100] or "Voice Room").strip()

    def _register_channel(self, channel_id: int, owner_id: int):
        self._temp_channels[channel_id] = owner_id
        self.bot.temp_voice_channel_ids.add(channel_id)

    def _unregister_channel(self, channel_id: int):
        self._temp_channels.pop(channel_id, None)
        self.bot.temp_voice_channel_ids.discard(channel_id)

    def _build_channel_name(self, member: discord.Member, name_format: str) -> str:
        fmt = name_format or "🔊 {user}"
        try:
            raw = fmt.format(user=member.display_name, username=member.name)
        except (KeyError, ValueError):
            raw = f"🔊 {member.display_name}"
        return self._sanitize_channel_name(raw)

    async def _create_temp_channel(
        self,
        member: discord.Member,
        cfg: dict,
    ) -> discord.VoiceChannel | None:
        guild = member.guild
        lobby_id = cfg.get("temp_voice_lobby_id")
        lobby = guild.get_channel(lobby_id) if lobby_id else None
        if not isinstance(lobby, discord.VoiceChannel):
            return None

        category_id = cfg.get("temp_voice_category_id")
        category = guild.get_channel(category_id) if category_id else lobby.category

        user_limit = int(cfg.get("temp_voice_user_limit") or 0)
        if user_limit < 0:
            user_limit = 0
        if user_limit > 99:
            user_limit = 99

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(
                connect=True,
                view_channel=True,
            ),
            member: discord.PermissionOverwrite(
                manage_channels=True,
                move_members=True,
                mute_members=True,
                deafen_members=True,
                priority_speaker=True,
            ),
            guild.me: discord.PermissionOverwrite(
                manage_channels=True,
                move_members=True,
                connect=True,
            ),
        }

        try:
            channel = await guild.create_voice_channel(
                name=self._build_channel_name(member, cfg.get("temp_voice_name_format", "")),
                category=category,
                overwrites=overwrites,
                user_limit=user_limit,
                reason=f"Temp voice for {member}",
            )
            self._register_channel(channel.id, member.id)
            await member.move_to(channel)
            logger.info(
                "🎙️ สร้าง temp voice %s สำหรับ %s ใน %s",
                channel.name,
                member,
                guild.name,
            )
            return channel
        except discord.HTTPException as exc:
            logger.error("❌ สร้าง temp voice ล้มเหลว: %s", exc)
            return None

    async def _delete_temp_channel(self, channel: discord.VoiceChannel):
        self._unregister_channel(channel.id)
        try:
            await channel.delete(reason="Temp voice channel empty")
            logger.info("🗑️ ลบ temp voice %s", channel.name)
        except discord.NotFound:
            pass
        except discord.HTTPException as exc:
            logger.error("❌ ลบ temp voice ล้มเหลว: %s", exc)

    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ):
        if member.bot or before.channel == after.channel:
            return

        cfg = await async_get_server_config(member.guild.id)
        if not cfg.get("temp_voice_enabled"):
            return

        lobby_id = cfg.get("temp_voice_lobby_id")
        if not lobby_id:
            return

        guild_id = member.guild.id

        if after.channel and after.channel.id == lobby_id:
            async with self._lock_for(guild_id):
                if after.channel and after.channel.id == lobby_id:
                    await self._create_temp_channel(member, cfg)
            return

        if before.channel and before.channel.id in self._temp_channels:
            if len(before.channel.members) == 0:
                await self._delete_temp_channel(before.channel)


async def setup(bot: commands.Bot):
    await bot.add_cog(TempVoice(bot))
