import discord
from discord import app_commands
from discord.ext import commands

from utils import async_get_server_config


def _fmt_channel(guild: discord.Guild, channel_id: int | None) -> str:
    if not channel_id:
        return "—"
    ch = guild.get_channel(channel_id)
    return ch.mention if ch else f"`{channel_id}` (ไม่พบ)"


class GuildConfig(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(
        name="view_config",
        description="ดูการตั้งค่าปัจจุบันของเซิร์ฟเวอร์นี้",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def view_config(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        cfg = await async_get_server_config(gid)

        exempt_channels = cfg.get("exempt_channels") or []
        exempt_mentions = []
        for cid in exempt_channels[:10]:
            ch = interaction.guild.get_channel(cid)
            exempt_mentions.append(ch.mention if ch else f"`{cid}`")
        if len(exempt_channels) > 10:
            exempt_mentions.append(f"... และอีก {len(exempt_channels) - 10} ช่อง")

        allowed = cfg.get("allowed_link_domains") or []
        allowed_text = ", ".join(f"`{d}`" for d in allowed) if allowed else "—"

        embed = discord.Embed(
            title=f"⚙️ การตั้งค่า — {interaction.guild.name}",
            color=discord.Color.blue(),
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(
            name="🔔 ช่องแจ้งเตือน Voice",
            value=_fmt_channel(interaction.guild, cfg.get("notify_channel_id")),
            inline=False,
        )

        join_id = cfg.get("join_here_channel_id")
        join_name = cfg.get("join_here_channel_name")
        if join_id or join_name:
            join_val = _fmt_channel(interaction.guild, join_id)
            if join_name:
                join_val += f" ({join_name})"
        else:
            join_val = "—"
        embed.add_field(name="🔇 Join Here (ไม่แจ้ง)", value=join_val, inline=False)

        embed.add_field(
            name="🔗 ยกเว้นกรองลิงก์ทั้งเซิร์ฟ",
            value="✅ ใช่" if cfg.get("exempt_guild") else "❌ ไม่",
            inline=True,
        )
        embed.add_field(
            name="📋 ช่องยกเว้นลิงก์",
            value="\n".join(exempt_mentions) if exempt_mentions else "—",
            inline=False,
        )
        embed.add_field(name="✅ โดเมนลิงก์ที่อนุญาต", value=allowed_text, inline=False)

        temp_on = cfg.get("temp_voice_enabled")
        if temp_on:
            lobby = _fmt_channel(interaction.guild, cfg.get("temp_voice_lobby_id"))
            cat_id = cfg.get("temp_voice_category_id")
            cat = interaction.guild.get_channel(cat_id) if cat_id else None
            cat_text = cat.name if cat else "— (ใช้ category ของ lobby)"
            temp_lines = (
                f"สถานะ: ✅ เปิด\n"
                f"Lobby: {lobby}\n"
                f"Category: {cat_text}\n"
                f"ชื่อห้อง: `{cfg.get('temp_voice_name_format', '🔊 {user}')}`\n"
                f"จำกัดคน: {cfg.get('temp_voice_user_limit') or 'ไม่จำกัด'}"
            )
        else:
            temp_lines = "❌ ปิด (ตั้งค่าได้ที่ Dashboard)"
        embed.add_field(name="🎙️ Temp Voice", value=temp_lines, inline=False)

        embed.set_footer(text="แก้ไขการตั้งค่าได้ที่ Web Dashboard")

        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(
        name="server_info",
        description="ดูข้อมูลเซิร์ฟเวอร์ปัจจุบัน",
    )
    async def server_info(self, interaction: discord.Interaction):
        guild = interaction.guild
        humans = sum(1 for m in guild.members if not m.bot)
        bots = sum(1 for m in guild.members if m.bot)

        embed = discord.Embed(
            title=f"🏠 {guild.name}",
            color=discord.Color.green(),
            timestamp=discord.utils.utcnow(),
        )
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.add_field(name="ID", value=f"`{guild.id}`", inline=True)
        embed.add_field(name="เจ้าของ", value=guild.owner.mention if guild.owner else "—", inline=True)
        embed.add_field(name="สร้างเมื่อ", value=discord.utils.format_dt(guild.created_at, "R"), inline=True)
        embed.add_field(name="สมาชิก", value=f"{guild.member_count:,}", inline=True)
        embed.add_field(name="คน / บอท", value=f"{humans:,} / {bots:,}", inline=True)
        embed.add_field(name="ช่องทั้งหมด", value=str(len(guild.channels)), inline=True)
        embed.add_field(name="บทบาท", value=str(len(guild.roles)), inline=True)
        embed.add_field(name="อีโมจิ", value=str(len(guild.emojis)), inline=True)
        embed.add_field(name="Boost", value=str(guild.premium_subscription_count or 0), inline=True)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            msg = "❌ ต้องมีสิทธิ์ Administrator"
        else:
            msg = "❌ คำสั่งล้มเหลว ลองใหม่อีกครั้ง"

        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(GuildConfig(bot))
