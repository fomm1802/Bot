import discord
from discord import app_commands
from discord.ext import commands


HELP_SECTIONS: list[tuple[str, list[tuple[str, str]]]] = [
    (
        "🎙️ Temp Voice",
        [
            ("Dashboard", "ตั้ง Lobby, Category, ชื่อห้อง, จำกัดคน"),
            ("/view_config", "ดูการตั้งค่า Temp Voice ปัจจุบัน"),
        ],
    ),
    (
        "🔔 แจ้งเตือน Voice",
        [
            ("Dashboard", "ตั้งช่องแจ้งเตือนและ Join Here"),
            ("/view_config", "ดูการตั้งค่าทั้งหมด"),
        ],
    ),
    (
        "🔗 กรองลิงก์",
        [
            ("Dashboard", "ตั้งค่ายกเว้นและโดเมนที่อนุญาต"),
            ("/link_filter_status", "ดูสถานะตัวกรองลิงก์"),
            ("/add_exempt_channel", "ยกเว้นช่อง (slash)"),
            ("/allow_link_domain", "อนุญาตโดเมน (slash)"),
        ],
    ),
    (
        "📨 Invite Hub",
        [
            ("/invite_sync_now", "ซิงก์ invite ทุกเซิร์ฟเวอร์ทันที"),
            ("/invite_set_interval", "ตั้งช่วงซิงก์อัตโนมัติ (วินาที)"),
        ],
    ),
    (
        "🛠️ เครื่องมือ",
        [
            ("/bot_status", "ดูสถานะ uptime และทรัพยากรบอท"),
            ("/server_info", "ดูข้อมูลเซิร์ฟเวอร์ปัจจุบัน"),
            ("/view_config", "ดูการตั้งค่าของเซิร์ฟเวอร์นี้"),
            ("/upload_emojis_gawrgura", "อัปโหลดอีโมจิจากโฟลเดอร์ Emoji"),
            ("/help", "แสดงเมนูคำสั่งนี้"),
        ],
    ),
]


class HelpMenu(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="help", description="แสดงรายการคำสั่งทั้งหมดของบอท")
    async def help_command(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📖 คู่มือคำสั่งบอท",
            description="คำสั่ง Slash ที่ใช้ได้ในเซิร์ฟเวอร์นี้",
            color=discord.Color.blurple(),
            timestamp=discord.utils.utcnow(),
        )

        for section_title, commands_list in HELP_SECTIONS:
            lines = "\n".join(f"`{name}` — {desc}" for name, desc in commands_list)
            embed.add_field(name=section_title, value=lines, inline=False)

        embed.set_footer(text="ตั้งค่าหลักผ่าน Web Dashboard — พอร์ตตาม WEBHOOK_PORT")
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(HelpMenu(bot))
