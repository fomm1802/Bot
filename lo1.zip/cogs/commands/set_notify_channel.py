from discord.ext import commands
from discord import app_commands
import discord
import logging
from utils import async_get_server_config, async_save_server_config

class SetNotifyChannel(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="set_notify_channel", description="ตั้งค่าช่องแจ้งเตือนสำหรับกิลนี้")
    @app_commands.checks.has_permissions(administrator=True)
    async def set_notify_channel(self, interaction: discord.Interaction):
        gid, cid = str(interaction.guild.id), interaction.channel.id
        conf = await async_get_server_config(gid) or {}
        if conf.get("notify_channel_id") == cid:
            await interaction.response.send_message("⚠️ ช่องนี้ถูกตั้งค่าเป็นช่องแจ้งเตือนอยู่แล้ว", ephemeral=True)
            return
        conf["notify_channel_id"] = cid
        await async_save_server_config(gid, conf)
        await interaction.response.send_message(f"🔔 ตั้งค่าช่องแจ้งเตือนเป็น: <#{cid}>", ephemeral=True)

    @app_commands.command(name="clear_notify_channel", description="ล้างช่องแจ้งเตือน voice")
    @app_commands.checks.has_permissions(administrator=True)
    async def clear_notify_channel(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        conf = await async_get_server_config(gid) or {}
        if not conf.get("notify_channel_id"):
            await interaction.response.send_message("⚠️ ยังไม่ได้ตั้งช่องแจ้งเตือน", ephemeral=True)
            return

        conf["notify_channel_id"] = None
        await async_save_server_config(gid, conf)
        await interaction.response.send_message("✅ ล้างช่องแจ้งเตือนแล้ว", ephemeral=True)

    @app_commands.command(name="set_join_here_channel", description="ตั้งช่อง Join Here (ไม่แจ้งเมื่อเข้า)")
    @app_commands.checks.has_permissions(administrator=True)
    async def set_join_here_channel(
        self,
        interaction: discord.Interaction,
        channel: discord.VoiceChannel,
    ):
        gid = str(interaction.guild.id)
        conf = await async_get_server_config(gid) or {}
        if conf.get("join_here_channel_id") == channel.id:
            await interaction.response.send_message("⚠️ ช่องนี้ถูกตั้งเป็น Join Here อยู่แล้ว", ephemeral=True)
            return

        conf["join_here_channel_id"] = channel.id
        conf["join_here_channel_name"] = channel.name
        await async_save_server_config(gid, conf)
        await interaction.response.send_message(
            f"✅ ตั้ง Join Here เป็น **{channel.name}** แล้ว",
            ephemeral=True,
        )

    @app_commands.command(name="clear_join_here_channel", description="ล้างช่อง Join Here")
    @app_commands.checks.has_permissions(administrator=True)
    async def clear_join_here_channel(self, interaction: discord.Interaction):
        gid = str(interaction.guild.id)
        conf = await async_get_server_config(gid) or {}
        if not conf.get("join_here_channel_id") and not conf.get("join_here_channel_name"):
            await interaction.response.send_message("⚠️ ยังไม่ได้ตั้งช่อง Join Here", ephemeral=True)
            return

        conf["join_here_channel_id"] = None
        conf["join_here_channel_name"] = None
        await async_save_server_config(gid, conf)
        await interaction.response.send_message("✅ ล้างช่อง Join Here แล้ว", ephemeral=True)

    @set_notify_channel.error
    async def _err(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("❌ คุณไม่มีสิทธิ์ใช้คำสั่งนี้", ephemeral=True)
        else:
            logging.error(f"❌ เกิดข้อผิดพลาด: {error}")
            await interaction.response.send_message("❌ ตั้งค่าช่องแจ้งเตือนล้มเหลว", ephemeral=True)

    async def cog_app_command_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            message = "❌ ต้องมีสิทธิ์ Administrator"
        else:
            logging.error(f"App command error in SetNotifyChannel: {error}")
            message = "❌ คำสั่งล้มเหลว ลองใหม่อีกครั้ง"

        if interaction.response.is_done():
            await interaction.followup.send(message, ephemeral=True)
        else:
            await interaction.response.send_message(message, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(SetNotifyChannel(bot))
