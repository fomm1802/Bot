﻿import time

import discord
import psutil
from discord import app_commands
from discord.ext import commands


def format_uptime(seconds: int) -> str:
    days, rem = divmod(seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)

    parts = []
    if days:
        parts.append(f"{days}d")
    if hours or parts:
        parts.append(f"{hours}h")
    if minutes or parts:
        parts.append(f"{minutes}m")
    parts.append(f"{seconds}s")
    return " ".join(parts)


class BotStatus(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.process = psutil.Process()

    @app_commands.command(name="bot_status", description="ดูสถานะ uptime และทรัพยากรของบอท")
    async def show_bot_status(self, interaction: discord.Interaction):
        uptime = int(time.time() - getattr(self.bot, "start_time", time.time()))
        total_members = sum((guild.member_count or 0) for guild in self.bot.guilds)
        memory_mb = self.process.memory_info().rss / 1024 / 1024
        cpu_percent = psutil.cpu_percent(interval=None)

        embed = discord.Embed(
            title="📊 สถานะบอท",
            color=discord.Color.green() if self.bot.is_ready() else discord.Color.orange(),
            timestamp=discord.utils.utcnow(),
        )
        embed.add_field(name="ออนไลน์เป็น", value=str(self.bot.user), inline=False)
        embed.add_field(name="เซิร์ฟเวอร์", value=str(len(self.bot.guilds)), inline=True)
        embed.add_field(name="สมาชิกรวม", value=f"{total_members:,}", inline=True)
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)} ms", inline=True)
        embed.add_field(name="Uptime", value=format_uptime(uptime), inline=True)
        embed.add_field(name="CPU", value=f"{cpu_percent:.0f}%", inline=True)
        embed.add_field(name="RAM", value=f"{memory_mb:.0f} MB", inline=True)

        shard_count = getattr(self.bot, "shard_count", None)
        if shard_count:
            embed.add_field(name="Shards", value=str(shard_count), inline=True)

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(BotStatus(bot))
