# AGENTS.md — Wiki Schema & Agent Conventions

Purpose: define how the LLM should structure, update, and maintain the wiki. Drop this file in the wiki root and iterate on it as your agent learns your preferences.

1. Filename conventions
   - `pages/` — topic and entity pages (e.g. `pages/Deep_Learning.md`).
   - `sources/` — raw-source summaries and metadata (e.g. `sources/2026-06-01-article-title.md`).
   - `index.md` — content index (auto-updated by agent).
   - `log.md` — chronological log (append-only).

2. Page frontmatter (YAML)
   - `title`: human-friendly title
   - `type`: `entity|concept|source|note|analysis`
   - `tags`: list of tags
   - `date`: ISO date (for sources/notes)
   - `sources`: list of source filenames or IDs
   - `summary`: one-line summary (optional)

3. Ingest workflow (when a new source is added)
   - Read source fully, extract: metadata, one-paragraph summary, key claims, questions, facts, named entities.
   - Create a `sources/YYYY-MM-DD-slug.md` file containing extracted metadata and the summary.
   - Update or create pages for entities/concepts referenced by the source; on update include a `## Sources` section with links.
   - Update `index.md` with counts and one-line summaries.
   - Append an entry to `log.md` using the canonical prefix: `## [YYYY-MM-DD] ingest | Source Title`.

4. Query workflow (user asks questions)
   - Search `index.md` to shortlist pages, then read those pages to synthesize answer.
   - Provide explicit citations to wiki pages and sources in the answer.
   - Ask whether the result should be filed back into the wiki; if yes, create `notes/` or `analysis/` page and update `index.md` and `log.md`.

5. Lint / health-check rules
   - Flag contradictions: identical claims with conflicting dates/sources.
   - Find orphan pages: pages with zero inbound links.
   - Identify missing pages: frequently mentioned entities with no page.
   - Check `index.md` parity with actual pages.

6. Behavior & guardrails
   - Never overwrite raw files in `sources/`.
   - When unsure about ambiguous facts, create a `TODO` section in the relevant page rather than guessing.
   - Keep edits idempotent and small; include a short changelog entry at the bottom of updated pages.

7. Example frontmatter
```
---
title: "Transformer Models"
type: concept
tags: [ml, nlp]
date: 2026-06-25
sources: [sources/2026-06-01-attention.md]
summary: "Overview of transformer architecture and attention mechanisms."
---
```

8. Extending the schema
   - Add custom fields for your workflow (e.g., `confidence`, `reviewed_by`).
   - If using Obsidian, standardize an attachment folder (e.g. `raw/assets/`) and reference images locally.

Keep this file versioned and let the agent propose changes as you discover better conventions.
