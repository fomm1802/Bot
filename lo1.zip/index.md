# Wiki Index

This file is auto-maintained by the agent. It lists pages by category with a one-line summary.

## Entities

- [Example Entity](pages/Example_Entity.md) — one-line summary

## Concepts

- [Example Concept](pages/Example_Concept.md) — one-line summary

## Sources

- sources/YYYY-MM-DD-slug.md — source title (count of pages referenced)

## Notes & Analyses

- notes/2026-06-25-analysis.md — short description

--
Last updated: (agent will populate)
