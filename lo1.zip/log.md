# Wiki Log

Append-only log of ingests, queries, and maintenance actions. Use the prefix format so the agent can parse recent activity.

Example entry:

## [2026-06-26] ingest | Example Article Title

- summary: One-sentence summary of the article.
- files created/updated: sources/2026-06-26-example.md, pages/Example_Entity.md
- notes: Added cross-links to Example Concept

## [2026-06-20] lint | weekly-check

- summary: Found 3 orphan pages; created TODOs for two entities.
